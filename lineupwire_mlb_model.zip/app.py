# Streamlit MLB App Entry Point
import streamlit as st
st.title('LineupWire MLB Model')